# Testa BP3D.Glb.ToGltfJson do navegador compilado, sem abrir a interface.
# Uso: powershell -NoProfile -ExecutionPolicy Bypass -File native\test\gltf-check.ps1 <arquivo.glb>
param(
    [string]$GlbPath = (Join-Path $PSScriptRoot 'Box.glb')
)

$exe = Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) '3D Browser Pro.exe'
Write-Output ("exe:    " + $exe)
Write-Output ("entrada:" + $GlbPath)

$asm = [Reflection.Assembly]::LoadFrom($exe)
$type = $asm.GetType('BP3D.Glb')
if ($type -eq $null) { Write-Output 'FALHOU: tipo BP3D.Glb nao encontrado'; exit 1 }

$method = $type.GetMethod('ToGltfJson', [Reflection.BindingFlags]'Static,Public,NonPublic')
$bytes = [IO.File]::ReadAllBytes($GlbPath)
Write-Output ("glb:    " + $bytes.Length + " bytes")

try {
    $json = $method.Invoke($null, @(, $bytes))
} catch {
    Write-Output ("FALHOU: " + $_.Exception.InnerException.Message)
    exit 1
}

Write-Output ("gltf:   " + $json.Length + " chars")
Write-Output ("inicio: " + $json.Substring(0, [Math]::Min(160, $json.Length)))

$obj = $json | ConvertFrom-Json
$buffers = @($obj.buffers)
$meshes = @($obj.meshes)
$nodes = @($obj.nodes)
$uri = $buffers[0].uri
$ok = $true

if ($obj.asset.version -ne '2.0') { Write-Output 'FALHOU: asset.version'; $ok = $false }
if ($buffers.Count -lt 1) { Write-Output 'FALHOU: sem buffers'; $ok = $false }
if ($uri -notlike 'data:application/octet-stream;base64,*') { Write-Output 'FALHOU: buffer sem data uri'; $ok = $false }
if ($buffers[0].byteLength -lt 1) { Write-Output 'FALHOU: byteLength zerado'; $ok = $false }
if ($meshes.Count -lt 1) { Write-Output 'FALHOU: sem meshes'; $ok = $false }

Write-Output ("asset.version: " + $obj.asset.version)
Write-Output ("buffers: " + $buffers.Count + "  byteLength=" + $buffers[0].byteLength + "  uri=" + $uri.Substring(0, [Math]::Min(40, $uri.Length)))
Write-Output ("meshes: " + $meshes.Count + "  nodes: " + $nodes.Count)

if ($ok) { Write-Output 'OK - glTF autocontido valido'; exit 0 }
exit 1
