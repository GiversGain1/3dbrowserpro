// gerado por tools/seal.ps1 â€” nao editar a mao
namespace BP3D
{
    internal static class SealData
    {
        internal const string Files =
            "home.html=1150805ac0afb9af7c82862e726084c5a443435ddd47969bd7c0924e35407be9;" +
            "native/ui/viewer.html=32530cc8bb84973c3c07d0f60c795aa8cb1d2e06a564f31a85ff16b474a87e03;" +
            "native/ui/panel.html=905fa505536e27638fa07ef51577359034e8edbd6ebe91e59c9b51c41409e071;" +
            "native/ui/panel.css=32356ab7d66b53cca3dd04429bd11bf4fa941d4dea4225ed7cb0e8333b0937a9;" +
            "native/ui/panel.js=8231024e75d6d4e4f0a0bd2ef62582efd7c6d8a950f9eef6df77b95b19ef1f68;" +
            "native/ui/viewer.css=dba503a8ccd540201358a33203a69eab250bd19e781fc06abbb42bc046795629;" +
            "native/inject/shim.js=18b80633be5436f84cfa7dc4b9db7f47caf7a0e53140ab79e1110e80bed5e60e;" +
            "src/content/hook.js=03ddb352c7271f1413c3a0ad294d1e54805ec3c0ce9ac5977f3d61d1d349282d;" +
            "assets/icon.ico=3301506545a72557a5ec612326b6c1f9d4225d1ab84a61ca0ef93ddebf48ac95;" +
            "assets/logos/livepix.svg=5371f63d9d81c878f7b79adfab473878f91fbdbca248bd4f296a56ec7053f1c9;" +
            "assets/logos/sansland.png=179ed2debe646f82993707f6b645347b12b39a18c363de03181cc4eb8e999193;" +
            "";
    }
}
