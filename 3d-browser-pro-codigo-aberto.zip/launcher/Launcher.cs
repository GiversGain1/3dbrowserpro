// 3D Browser Pro — lançador (C# 5, .NET Framework, WinExe)
// Abre Chrome/Edge/Brave com um perfil exclusivo e a extensão desta pasta já carregada.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class Program
{
    private static readonly string[] CandidatePaths = new string[]
    {
        @"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
        @"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe",
        @"%LocalAppData%\Google\Chrome\Application\chrome.exe",
        @"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe",
        @"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe",
        @"%LocalAppData%\BraveSoftware\Brave-Browser\Application\brave.exe",
        @"%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe",
        @"%LocalAppData%\Chromium\Application\chrome.exe"
    };

    [STAThread]
    private static void Main(string[] args)
    {
        try
        {
            Run(args);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Não foi possível abrir o 3D Browser Pro:\n\n" + ex.Message,
                "3D Browser Pro",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    private static string Quote(string value)
    {
        return "\"" + value.Replace("\"", "") + "\"";
    }

    private static string FindBrowser()
    {
        string custom = Environment.GetEnvironmentVariable("BP3D_BROWSER");
        if (!string.IsNullOrEmpty(custom) && File.Exists(custom)) return custom;

        for (int i = 0; i < CandidatePaths.Length; i++)
        {
            string path = Environment.ExpandEnvironmentVariables(CandidatePaths[i]);
            if (File.Exists(path)) return path;
        }

        string[] exes = new string[] { "chrome.exe", "msedge.exe", "brave.exe" };
        string[] roots = new string[]
        {
            @"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\",
            @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\"
        };

        for (int e = 0; e < exes.Length; e++)
        {
            for (int r = 0; r < roots.Length; r++)
            {
                try
                {
                    using (Microsoft.Win32.RegistryKey key =
                        Microsoft.Win32.Registry.LocalMachine.OpenSubKey(roots[r] + exes[e]))
                    {
                        if (key == null) continue;
                        string value = key.GetValue(null) as string;
                        if (string.IsNullOrEmpty(value)) continue;
                        value = value.Trim('"');
                        if (File.Exists(value)) return value;
                    }
                }
                catch
                {
                    // chave inacessível: tenta a próxima
                }
            }
        }

        return null;
    }

    private static string HomePage(string extDir)
    {
        string home = Path.Combine(extDir, "home.html");
        if (!File.Exists(home)) return null;
        return "file:///" + home.Replace('\\', '/');
    }

    private static string NormalizeTarget(string raw)
    {
        if (raw.IndexOf("://", StringComparison.Ordinal) >= 0) return raw;
        if (File.Exists(raw)) return "file:///" + Path.GetFullPath(raw).Replace('\\', '/');
        return "https://" + raw;
    }

    private static void Run(string[] args)
    {
        string extDir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(
            Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);

        if (!File.Exists(Path.Combine(extDir, "manifest.json")))
        {
            MessageBox.Show(
                "O arquivo manifest.json não está ao lado do executável.\n\n" +
                "Mantenha o \"3D Browser Pro.exe\" dentro da pasta da extensão.",
                "3D Browser Pro",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            return;
        }

        string browser = FindBrowser();
        if (browser == null)
        {
            MessageBox.Show(
                "Não encontrei o Chrome, o Edge nem o Brave instalado.\n\n" +
                "Instale um deles para usar o 3D Browser Pro.\n" +
                "Alternativa: defina a variável BP3D_BROWSER com o caminho completo do navegador.",
                "3D Browser Pro",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        string profileDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "3D Browser Pro",
            "perfil");
        Directory.CreateDirectory(profileDir);

        List<string> parts = new List<string>();
        parts.Add("--user-data-dir=" + Quote(profileDir));
        parts.Add("--load-extension=" + Quote(extDir));
        parts.Add("--disable-extensions-except=" + Quote(extDir));
        // Mantém --load-extension funcionando nas versões recentes do Chromium.
        parts.Add("--disable-features=DisableLoadExtensionCommandLineSwitch,Translate");
        parts.Add("--no-first-run");
        parts.Add("--no-default-browser-check");
        parts.Add("--disable-session-crashed-bubble");
        parts.Add("--start-maximized");

        string target = null;
        for (int i = 0; i < args.Length; i++)
        {
            if (args[i].StartsWith("--", StringComparison.Ordinal)) continue;
            target = NormalizeTarget(args[i]);
            break;
        }
        if (target == null) target = HomePage(extDir);
        if (target != null) parts.Add(Quote(target));

        ProcessStartInfo info = new ProcessStartInfo();
        info.FileName = browser;
        info.Arguments = string.Join(" ", parts.ToArray());
        info.WorkingDirectory = extDir;
        info.UseShellExecute = false;

        Process.Start(info);
    }
}
