# 3D Browser Pro - empacotamento.
#   poderes: dist/3D-Browser-Pro-<versao>-win64.zip  (usuario baixa, extrai e roda o exe)
#            ../../3d-browser-pro-codigo-aberto.zip  (codigo-fonte para o GitHub)
# Uso: powershell -NoProfile -ExecutionPolicy Bypass -File tools\pack.ps1 [-SkipBuild] [-Version 1.1.0]
param(
  [switch]$SkipBuild,
  [string]$Version = '1.1.0'
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
  if (-not $SkipBuild) {
    & cmd /c "tools\build-browser.bat"
    if ($LASTEXITCODE -ne 0) { throw ("build falhou (exit " + $LASTEXITCODE + ") - veja native\build-log.txt") }
  }
  if (-not (Test-Path -LiteralPath '3D Browser Pro.exe')) { throw '3D Browser Pro.exe nao encontrado - compile primeiro' }

  $dist = Join-Path $root 'dist'
  if (-not (Test-Path -LiteralPath $dist)) { New-Item -ItemType Directory -Path $dist | Out-Null }

  function New-CleanDir([string]$path) {
    if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force }
    New-Item -ItemType Directory -Path $path | Out-Null
  }

  # ZIP com caminhos "/" de verdade (o Compress-Archive grava "\\", que quebra no unzip/7-Zip).
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  function New-Zip([string]$zipPath, [string]$sourceDir, [string]$prefix) {
    if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
    $base = (Resolve-Path -LiteralPath $sourceDir).Path.TrimEnd('\')
    $zip = [IO.Compression.ZipFile]::Open($zipPath, 'Create')
    try {
      $files = Get-ChildItem -LiteralPath $base -Recurse -File -Force
      foreach ($file in $files) {
        $rel = $file.FullName.Substring($base.Length + 1) -replace '\\', '/'
        if ($prefix) { $rel = $prefix.TrimEnd('/') + '/' + $rel }
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
          $zip, $file.FullName, $rel, [IO.Compression.CompressionLevel]::Optimal)
      }
    } finally {
      $zip.Dispose()
    }
  }

  # ---------- 1. pacote pronto para usar ----------
  $name = '3D Browser Pro ' + $Version
  $stage = Join-Path $dist $name
  New-CleanDir $stage

  $runtime = @(
    '3D Browser Pro.exe',
    'Microsoft.Web.WebView2.Core.dll',
    'Microsoft.Web.WebView2.WinForms.dll',
    'WebView2Loader.dll',
    'home.html',
    'README.md'
  )
  foreach ($f in $runtime) { Copy-Item -LiteralPath (Join-Path $root $f) -Destination (Join-Path $stage $f) -Force }

  Copy-Item -LiteralPath (Join-Path $root 'assets') -Destination (Join-Path $stage 'assets') -Recurse -Force

  $ui = Join-Path $stage 'native'
  New-Item -ItemType Directory -Path $ui | Out-Null
  Copy-Item -LiteralPath (Join-Path $root 'native\ui') -Destination (Join-Path $ui 'ui') -Recurse -Force
  Copy-Item -LiteralPath (Join-Path $root 'native\inject') -Destination (Join-Path $ui 'inject') -Recurse -Force
  $hookDir = Join-Path $stage 'src\content'
  New-Item -ItemType Directory -Path $hookDir -Force | Out-Null
  Copy-Item -LiteralPath (Join-Path $root 'src\content\hook.js') -Destination (Join-Path $hookDir 'hook.js') -Force

  $readme = @"
3D Browser Pro $Version - versao pronta para usar
====================================================

1. Extraia esta pasta inteira (nao rode o .exe de dentro do .zip).
2. De duplo clique em "3D Browser Pro.exe".
3. A janela abre na pagina inicial do proprio navegador (home.html).

Nao precisa instalar nada alem do Microsoft Edge WebView2 Runtime, que ja vem
no Windows 11 e na maioria dos Windows 10 atualizados. Se o app avisar que o
WebView2 falta, instale o runtime oficial:
  https://go.microsoft.com/fwlink/p/?LinkId=2124703

Dicas
-----
- Nao separe o .exe das DLLs, da pasta assets, de native\ ou de src\: tudo
  isso e o navegador. Mova a pasta inteira, se precisar.
- O app tambem se recusa a abrir se algum arquivo do programa for alterado
  (protecao anti-adulteracao). Reinstale extraindo o .zip de novo.
- Historico, cookies e log ficam em %LOCALAPPDATA%\3D Browser Pro\.
- Downloads vao para Downloads\3D Browser Pro\<site>\ (configuravel no engrenagem).
- Abrir direto num site: arraste um link sobre o .exe ou rode
  "3D Browser Pro.exe" tripo3d.ai
- Doacao (LivePix) e o Discord do SanSland ficam no botao da pagina inicial.

Mais detalhes: README.md
"@
  $utf8 = New-Object System.Text.UTF8Encoding($true)
  [IO.File]::WriteAllText((Join-Path $stage 'LEIA-ME.txt'), $readme, $utf8)

  $zip = Join-Path $dist ('3D-Browser-Pro-' + $Version + '-win64.zip')
  New-Zip $zip $stage $name
  Write-Output ('dist: ' + $zip + ' (' + [math]::Round((Get-Item -LiteralPath $zip).Length / 1MB, 2) + ' MB)')

  # ---------- 2. pacote de codigo-fonte (GitHub) ----------
  $srcStage = Join-Path $dist '_fonte'
  New-CleanDir $srcStage

  foreach ($d in @('assets', 'src', 'tools', 'launcher')) {
    Copy-Item -LiteralPath (Join-Path $root $d) -Destination (Join-Path $srcStage $d) -Recurse -Force
  }
  foreach ($f in @('.gitignore', 'README.md', 'home.html', 'manifest.json', 'Abrir 3D Browser Pro.bat',
                   'Microsoft.Web.WebView2.Core.dll', 'Microsoft.Web.WebView2.WinForms.dll', 'WebView2Loader.dll')) {
    Copy-Item -LiteralPath (Join-Path $root $f) -Destination (Join-Path $srcStage $f) -Force
  }

  $nativeStage = Join-Path $srcStage 'native'
  New-Item -ItemType Directory -Path $nativeStage | Out-Null
  Get-ChildItem -LiteralPath (Join-Path $root 'native') -File |
    Where-Object { $_.Extension -ne '.log' } |
    ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $nativeStage $_.Name) -Force }
  foreach ($d in @('ui', 'inject', 'test')) {
    Copy-Item -LiteralPath (Join-Path $root ('native\' + $d)) -Destination (Join-Path $nativeStage $d) -Recurse -Force
  }
  $vendorStage = Join-Path $nativeStage 'vendor'
  New-Item -ItemType Directory -Path $vendorStage -Force | Out-Null
  Copy-Item -LiteralPath (Join-Path $root 'native\vendor\lib') -Destination (Join-Path $vendorStage 'lib') -Recurse -Force
  foreach ($f in @('WebView2Loader.dll', 'MicrosoftEdgeWebview2Setup.exe', 'sdk-version.txt')) {
    Copy-Item -LiteralPath (Join-Path $root ('native\vendor\' + $f)) -Destination (Join-Path $vendorStage $f) -Force
  }

  $srcZip = Join-Path $root '3d-browser-pro-codigo-aberto.zip'
  New-Zip $srcZip $srcStage ''
  Remove-Item -LiteralPath $srcStage -Recurse -Force
  Write-Output ('github: ' + $srcZip + ' (' + [math]::Round((Get-Item -LiteralPath $srcZip).Length / 1MB, 2) + ' MB)')
}
finally {
  Pop-Location
}
