@echo off
rem 3D Browser Pro - compila o navegador proprio (WinForms + WebView2).
rem Uso: cmd /c tools\build-browser.bat
setlocal
set "ROOT=%~dp0.."
pushd "%ROOT%"

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" goto :nocsc
if not exist "native\vendor\lib\Microsoft.Web.WebView2.Core.dll" goto :nosdk
if not exist "native\vendor\lib\Microsoft.Web.WebView2.WinForms.dll" goto :nosdk
if not exist "native\vendor\WebView2Loader.dll" goto :nosdk

rem assinatura SHA-256 dos arquivos carregados do disco (barreira anti-alteracao)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0seal.ps1"
if errorlevel 1 goto :fail

"%CSC%" -nologo -target:winexe -platform:anycpu -optimize+ ^
 -win32icon:assets\icon.ico ^
 -out:"3D Browser Pro.exe" ^
 -r:System.dll -r:System.Core.dll -r:System.Drawing.dll -r:System.Windows.Forms.dll ^
 -r:System.Web.Extensions.dll -r:System.IO.Compression.dll -r:System.IO.Compression.FileSystem.dll ^
 -r:native\vendor\lib\Microsoft.Web.WebView2.Core.dll ^
 -r:native\vendor\lib\Microsoft.Web.WebView2.WinForms.dll ^
 native\Program.cs native\splash.cs native\sniff.cs native\rigfbx.cs native\rigfit.cs native\fbxout.cs native\glbskin.cs native\meshout.cs native\decimate.cs native\zipout.cs native\shield.cs native\seal.g.cs > "native\build-log.txt" 2>&1

if errorlevel 1 goto :fail

copy /y "native\vendor\lib\Microsoft.Web.WebView2.Core.dll" "%ROOT%\" >nul
copy /y "native\vendor\lib\Microsoft.Web.WebView2.WinForms.dll" "%ROOT%\" >nul
copy /y "native\vendor\WebView2Loader.dll" "%ROOT%\" >nul

echo.
echo ok - "3D Browser Pro.exe" compilado, DLLs do WebView2 copiadas para a raiz.
popd
exit /b 0

:nocsc
echo Nao encontrei o csc.exe do .NET Framework v4.
popd
exit /b 1

:nosdk
echo Faltam as DLLs do WebView2 em native\vendor\lib ou o WebView2Loader.dll.
popd
exit /b 1

:fail
echo Falha ao compilar - detalhes em native\build-log.txt
popd
exit /b 1
