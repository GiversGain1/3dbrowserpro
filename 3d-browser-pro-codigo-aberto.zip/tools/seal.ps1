# Gera native/seal.g.cs: o SHA-256 dos arquivos que o app carrega do disco.
# Assim o exe sabe se home.html / visualizador / painel / ícone foram trocados.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$files = @(
  'home.html',
  'native/ui/viewer.html',
  'native/ui/panel.html',
  'native/ui/panel.css',
  'native/ui/panel.js',
  'native/ui/viewer.css',
  'native/inject/shim.js',
  'src/content/hook.js',
  'assets/icon.ico',
  'assets/logos/livepix.svg',
  'assets/logos/sansland.png'
)

$sb = New-Object System.Text.StringBuilder
[void]$sb.AppendLine('// gerado por tools/seal.ps1 — nao editar a mao')
[void]$sb.AppendLine('namespace BP3D')
[void]$sb.AppendLine('{')
[void]$sb.AppendLine('    internal static class SealData')
[void]$sb.AppendLine('    {')
[void]$sb.AppendLine('        internal const string Files =')

$count = 0
foreach ($f in $files) {
  $p = Join-Path $root ($f -replace '/', [IO.Path]::DirectorySeparatorChar)
  if (-not (Test-Path -LiteralPath $p)) { continue }
  $h = (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLower()
  [void]$sb.AppendLine('            "' + $f + '=' + $h + ';" +')
  $count++
}
[void]$sb.AppendLine('            "";')
[void]$sb.AppendLine('    }')
[void]$sb.AppendLine('}')

$out = Join-Path $root 'native/seal.g.cs'
[IO.File]::WriteAllText($out, $sb.ToString(), (New-Object System.Text.UTF8Encoding($false)))
Write-Host ("seal: " + $count + " arquivo(s) assinado(s) -> native/seal.g.cs")
