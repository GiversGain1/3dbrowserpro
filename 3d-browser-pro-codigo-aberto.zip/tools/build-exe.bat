@echo off
rem 3D Browser Pro - compila o atalho legado que abria o Brave com a extensao.
rem O navegador de verdade agora e o "3D Browser Pro.exe" (tools\build-browser.bat).
rem Este script so gera legacy\3D Browser Pro (atalho Brave).exe
setlocal
set "ROOT=%~dp0.."
pushd "%ROOT%"

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" goto :nocsc
if not exist "launcher\Launcher.cs" goto :nosrc
if not exist "legacy" mkdir "legacy"

"%CSC%" -nologo -target:winexe -platform:anycpu -optimize+ ^
 -win32icon:assets\icon.ico ^
 -out:"legacy\3D Browser Pro (atalho Brave).exe" ^
 -r:System.dll -r:System.Windows.Forms.dll -r:System.Drawing.dll ^
 launcher\Launcher.cs > "native\build-legacy-log.txt" 2>&1

if errorlevel 1 goto :fail
echo ok - legacy\3D Browser Pro (atalho Brave).exe
popd
exit /b 0

:nocsc
echo Nao encontrei o csc.exe do .NET Framework v4.
popd
exit /b 1

:nosrc
echo Falta launcher\Launcher.cs
popd
exit /b 1

:fail
echo Falha ao compilar - detalhes em native\build-legacy-log.txt
popd
exit /b 1
