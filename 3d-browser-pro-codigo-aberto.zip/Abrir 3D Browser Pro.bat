@echo off
rem 3D Browser Pro - abre o navegador proprio (3D Browser Pro.exe).
rem Uso: duplo clique, ou arraste um link sobre este arquivo.
setlocal
set "EXE=%~dp03D Browser Pro.exe"

if not exist "%EXE%" goto :semexe

start "" "%EXE%" %*
exit /b 0

:semexe
echo.
echo Nao encontrei "3D Browser Pro.exe" nesta pasta.
echo Compile primeiro com:  cmd /c tools\build-browser.bat
echo.
pause
exit /b 1
